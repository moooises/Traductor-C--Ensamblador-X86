int valor()
{
		return 2;
}

int main()
{
	int a=3,b=a,c[3];
	c[0]=8;
	printf("Hola %d",a);
	printf("El numero %d",2);
	scanf("valor a a", &a);

	if(c[0]==8)
	{
		b=b+1;
	}
	else
	{
		b=b-1;
	}

	while(c[0]!=8)
	{
		while(1>=1<=1)
		{
			if(1 || 1)
			{
				b=b*2;
			}
			else
			{
				c[0]=c[0]/2;
			}
		}
	}
}
